package com.springeltests.operators;

import java.util.List;

/**
 * by Irina.Petrovskaya, on 22.11.11, 13:26
 */
public class Test2 {
    private String o1;
    private String o2;
    private List<String> o3;
    private int[] o4;
    private List o5;
    private String o6;
    private List<Integer> selector;
    private List<MyBox> typesSelector;
    private String safeBoxSize;
    private List<Integer> boxSizes;

    public void setO1(String o1) {
        this.o1 = o1;
    }

    public String getO1() {
        return o1;
    }

    public void setO2(String o2) {
        this.o2 = o2;
    }

    public String getO2() {
        return o2;
    }

    public void setO3(List<String> o3) {
        this.o3 = o3;
    }

    public List<String> getO3() {
        return o3;
    }

    public void setO4(int[] o4) {
        this.o4 = o4;
    }

    public int[] getO4() {
        return o4;
    }

    public void setListOfLists(List o5) {
        this.o5 = o5;
    }

    public List getListOfLists() {
        return o5;
    }

    public void setO6(String o6) {
        this.o6 = o6;
    }

    public String getO6() {
        return o6;
    }

    public void setSelector(List<Integer> selector) {
        this.selector = selector;
    }

    public List<Integer> getSelector() {
        return selector;
    }

    public void setBoxSelector(List<MyBox> typesSelector) {
        this.typesSelector = typesSelector;
    }

    public List<MyBox> getBoxSelector() {
        return typesSelector;
    }

    public void setSafeBoxSize(String safeBoxSize) {
        this.safeBoxSize = safeBoxSize;
    }

    public String getSafeBoxSize() {
        return safeBoxSize;
    }

    public void setBoxSizes(List<Integer> boxSizes) {
        this.boxSizes = boxSizes;
    }

    public List<Integer> getBoxSizes() {
        return boxSizes;
    }
}
