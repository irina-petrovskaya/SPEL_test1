package com.springeltests.operators;

/**
 * by Irina.Petrovskaya, on 22.11.11, 18:27
 */
public class MyBox {
    int size;

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }
}
